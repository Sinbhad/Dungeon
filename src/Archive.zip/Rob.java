public class Rob extends Character implements Attack{
    public Rob(){
        setName("Rob");
        setAttackValue(40);
        setHealthValue(100);
        setSpeedValue(20);
    }
}
