public class Sword extends Item{
    public Sword(){
        setName("Sword");
        setAttackValue(20);
        setHpValue(-5);
    }
}
