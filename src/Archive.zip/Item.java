public class Item{
    String name;
    int value;

    public void setName(String name){
        this.name = name;
    }

    public void setAttackValue(int value){
        this.value = value;
    }

    public void setHpValue(int value){
        this.value = value;
    }

    public String getName(){
        return name;
    }

    public int getAttackValue(){
        return value;
    }

    public int getHpValue(){
        return value;
    }
}
