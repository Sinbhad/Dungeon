import lib.CircularlyLinkedList;
import lib.Node;

import java.util.Scanner;
import java.util.Random;

public class DungeonTester<T> {
    public static void dungeon(){
        Rob rob = new Rob();
        //Goblin goblin = new Goblin();
        //Sword sword = new Sword();


        Scanner keyboard = new Scanner(System.in);
        Random chanceNum = new Random();
        CircularlyLinkedList<Room> dungeon = new CircularlyLinkedList<>();


        Room room1 = new Room("Room 1", null, null, null, false);
        Room room2 = new Room("Room 2", null, null, null, false);
        Room room3 = new Room("Room 3", null, null, null, false);
        Room room4 = new Room("Room 4", null, null, null, false);
        Room room5 = new Room("Room 5", null, null, null, false);
        Room room6 = new Room("Room 6", null, null, null, false);
        Room room7 = new Room("Room 7", null, null, null, false);



        dungeon.add(room1);
        dungeon.add(room2);
        dungeon.add(room3);
        dungeon.add(room4);
        dungeon.add(room5);
        dungeon.add(room6);
        dungeon.add(room7);



        /* test
        Room tempRoom = dungeon.getValAtIndex(3);


        tempRoom.setCertain(sword, rob, goblin, false);

        System.out.println(tempRoom.getItem().getName());
        System.out.println(tempRoom.getEnemyCharacter().getName());
        System.out.println(tempRoom.getPlayerCharacter().getName());


        if(!tempRoom.getIsExit()){
            System.out.println("This room is not an exit");
        }


        System.out.println(dungeon.getSize());
         */


        int goblinRoomIndex = chanceNum.nextInt(7);
        Room goblinRoom = dungeon.getValAtIndex(goblinRoomIndex);
        goblinRoom.setEnemyCharacter(new Goblin());
        //System.out.println(goblinRoom.getName() + " " +  goblinRoom.getEnemyCharacter().getName());


        int swordRoomIndex = chanceNum.nextInt(7);
        Room swordRoom = dungeon.getValAtIndex(swordRoomIndex);
        swordRoom.setItem(new Sword());
        //System.out.println(swordRoom.getName() + " " + swordRoom.getItem().getName());

        int healthPotionRoomIndex = chanceNum.nextInt(7);
        Room healthPotionRoom = dungeon.getValAtIndex(healthPotionRoomIndex);
        healthPotionRoom.setItem(new HealthPotion());
        //System.out.println(healthPotionRoom.getName() + " " + healthPotionRoom.getItem().getName());

        int trapRoomIndex = chanceNum.nextInt(7);
        Room trapRoom = dungeon.getValAtIndex(trapRoomIndex);
        trapRoom.setItem(new Trap());
        //System.out.println(trapRoom.getName() + " " + trapRoom.getItem().getName());


        int exitRoomIndex = chanceNum.nextInt(7);
        Room exitRoom = dungeon.getValAtIndex(exitRoomIndex);
        exitRoom.setIsExit(true);
        //if(exitRoom.getIsExit()){
        //    System.out.println(exitRoom.getName() + " is an exit");
        //}



        room1.setPlayerCharacter(rob);
        Node currentDungeonRoom = dungeon.getHead();
        currentDungeonRoom.getValue();
        System.out.println("You have entered the dungeon");


        while(rob.getHealth() >0){
            currentDungeonRoom = choice(currentDungeonRoom);
            Room displayRoom = (Room) currentDungeonRoom.getValue();

            System.out.println(displayRoom.getName());
            if(displayRoom.getItem() != null){
                System.out.println(displayRoom.getItem().getName());
            }

            if(displayRoom.getEnemyCharacter() != null){
                System.out.println(displayRoom.getEnemyCharacter().getName());
            }

        }








    }

    public static Node choice(Node currentDungeonRoom){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Would you like to move left or right? (l/r) : ");
        String choice = keyboard.nextLine();
        if(choice.equals("l")){
            System.out.println("You have moved left");
            currentDungeonRoom = currentDungeonRoom.getLastNode();
        }else if(choice.equals("r")){
            System.out.println("You have moved right");
            currentDungeonRoom = currentDungeonRoom.getNextNode();
        }else{
            System.out.println("Invalid choice");
        }
        return currentDungeonRoom;
    }
}

