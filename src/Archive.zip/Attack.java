public interface Attack {
}
